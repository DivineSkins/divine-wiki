# @divineskins/ui

The Divine Skins design system as a package: the design tokens, a Tailwind preset that turns them into `divine-*` classes, and React components built from the website's live recipes. Use it so any Divine app (the website, the Celestial launcher, internal tools) looks like the site without copying styles around.

| Export | What it is |
|--------|-----------|
| `@divineskins/ui` | React components, `cn()`, the raw `tokens` object and `divineThemes` |
| `@divineskins/ui/tailwind.css` | Tailwind CSS v4 setup: every token as a `divine-*` class |
| `@divineskins/ui/tailwind-preset` | The same for Tailwind CSS v3, as a preset |
| `@divineskins/ui/themes.css` | The built-in themes (`original`, `halloween`), switched with one attribute |
| `@divineskins/ui/tokens.json` | The tokens themselves, the single source of truth |
| `@divineskins/ui/tokens.css` | The tokens as CSS custom properties (`--divine-primary`, `--divine-radius-xl`...), for styling without Tailwind |
| `npx divine-ui link-skill` | Makes the package's Claude Code skill visible in your project |

Components: <!-- components:start -->Button, IconTile, Badge, Chip, Card, Input, Textarea, Label, Field, Checkbox, Switch, Select, Popover, PickerTrigger, PopoverItem, DropdownMenu, Dialog, Tabs, TabsCount, Tooltip, Separator, Skeleton, EmptyState, Spinner, Progress, Avatar, Alert, Pagination, SegmentedControl, Accordion, Table, SearchInput, DivinePlusBadge<!-- components:end -->. Full API, variants and usage rules: [`skills/divine-ui/`](skills/divine-ui/SKILL.md).

Works with React 18 and 19, Tailwind v3 and v4, tailwind-merge v2 and v3, Vite and Next.js (the bundle is marked `"use client"`).

## Use it in another repo

### 1. Access

The package is private, on GitHub Packages, so installing it needs a GitHub token that can read DivineSkins packages:

- **Your machine:** a token with `read:packages`. With the GitHub CLI: `gh auth refresh -h github.com -s read:packages`, then `export GITHUB_TOKEN=$(gh auth token)` (or a classic personal access token with `read:packages`).
- **GitHub Actions in the other repo:** on GitHub, open the package's settings, then Manage Actions access, add that repo, and use the built-in `GITHUB_TOKEN` (`permissions: packages: read`).
- **Other CI or hosting builds** (Cloudflare, Vercel): a `read:packages` token as a `GITHUB_TOKEN` build variable.

Add an `.npmrc` to the repo. It holds no secret, only the variable name, so it is safe to commit, even in a public repo:

```ini
@divineskins:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

```bash
npm install @divineskins/ui
```

React, Radix and the class helpers are peer dependencies (npm 7+ installs missing ones), so the app keeps a single copy of each.

### 2. Tailwind

**Tailwind v4** (CSS config):

```css
/* app.css */
@import "tailwindcss";
@import "@divineskins/ui/tailwind.css"; /* tokens, and scans the components' classes */
@import "@divineskins/ui/themes.css";   /* optional: seasonal themes */
```

**Tailwind v3** (JS config):

```js
// tailwind.config.js
module.exports = {
  presets: [require("@divineskins/ui/tailwind-preset")],
  content: [
    "./src/**/*.{ts,tsx}",
    "./node_modules/@divineskins/ui/dist/**/*.js", // the components' own classes
  ],
}
```

and `@import "@divineskins/ui/themes.css";` in your CSS if you want the themes.

### 3. Fonts and the page

The components use Manrope (UI and body) and the headings use Poppins. Load both, for example:

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Poppins:wght@400;500;600;700&display=swap" />
```

Divine is dark only. Put the app on the void: `<body class="bg-divine-bg font-manrope text-divine-text">`.

```tsx
import { Button, IconTile } from "@divineskins/ui"
import { Download } from "lucide-react"

<Button>Install</Button>
<Button variant="secondary">Details</Button>
<IconTile tone="gold"><Download /></IconTile>
```

### 4. The Claude Code skill

The package ships a skill (`skills/divine-ui`) that tells Claude which component to use, the variants, tokens and rules. Claude Code reads skills from your project's `.claude/skills/`, never from `node_modules`, so link it once:

```bash
npx divine-ui link-skill          # symlink: follows package updates by itself
npx divine-ui link-skill --copy   # a copy you can commit (goes stale on updates)
```

To keep the link after fresh clones, add it to the app's `package.json`: `"postinstall": "divine-ui link-skill"`, and put `.claude/skills/divine-ui` in `.gitignore`. Claude Code picks the skill up in the next session; `/divine-ui` calls it by hand.

## Theming

Interactive brand color comes from four theme colors: `accent`, `accent-hover`, `highlight` and `icon-accent` (classes `bg-divine-accent`, `ring-divine-accent/50`, `text-divine-highlight`...). Each reads a CSS variable and falls back to the Divine purple, so nothing needs defining by default.

With `themes.css` imported, one attribute switches every component under it:

```tsx
document.documentElement.dataset.divineTheme = "halloween" // or "original"
```

`divineThemes` lists the built-in names (for a picker). A one-off theme is just the four variables on any element: `--divine-accent`, `--divine-accent-hover`, `--divine-highlight`, `--divine-icon-accent`. A new built-in theme goes in `tokens/tokens.json` under `themes`.

The website keeps its own seasonal theme system (`apps/web/src/styles/SiteTheme.css`) and points the package colors at it; a web test fails if its values and the package's `themes` drift apart. `divine-primary` stays the fixed brand purple (logo, marketing art); components use `divine-accent`.

## Use it in this repo

Apps in the monorepo link the source instead of installing a build, so a token edit shows up immediately and needs no publish. `apps/web` is wired this way; a new app copies the same four pieces:

1. `package.json`: `"@divineskins/ui": "file:../../packages/ui"`.
2. Tailwind: the preset, plus `../../packages/ui/src/**/*.{ts,tsx}` in `content`.
3. Vite: `resolve.conditions: ['@divineskins/source', ...defaultClientConditions]` (and the `ssr` twin) to load the TypeScript source, plus the small `divineUiImportsFromApp` resolver plugin so the package's own imports (React, Radix) resolve to the app's copies. Don't reach for `resolve.dedupe` instead: it also flattens the app's own nested Radix versions and breaks the build. And add `packages/ui` to `server.fs.allow`, or the dev server refuses to serve the package (403; builds and tests don't check this, so only `npm run dev` shows it). Copy all three from `apps/web/vite.config.js`.
4. `tsconfig.json`: `"customConditions": ["@divineskins/source"]`, `"preserveSymlinks": true`, and `react` / `react/*` paths pinned to the app's `@types/react`. See `apps/web/tsconfig.json` for why each is needed.

## Developing

```bash
cd packages/ui
npm install
npm run dev        # playground: every component and variant, plus a theme toggle
npm test           # components, tokens and import guards
npm run typecheck
npm run build      # dist/ via tsup
```

- **Tokens and themes:** edit `tokens/tokens.json`, then `npm run tokens` to regenerate `tokens.css`, `themes.css`, `tailwind.css` and `src/tokens.generated.ts` (a test fails if you forget). The web picks up the change through the preset; check its typecheck and look at the affected pages.
- **Components:** one file per component in `src/components/`, exported from `src/index.ts`. Copy the recipe from a live surface of the site, use `divine-*` classes over raw hex (add a token if one is missing), and use the theme colors for anything interactive. Every bare import must be a peer dependency: the web resolves them from its own `node_modules`, and `tests/imports.test.ts` fails otherwise. Add it to the playground and to `skills/divine-ui/references/components.md`.

## Releasing

Only apps in other repos need a release. Bump `version` in `package.json` (semver: a removed or renamed prop or variant is a major), then either:

- run the **Publish @divineskins/ui** workflow (Actions tab, `ui-publish.yml`) once the change is on `main`, or
- publish from your machine with a token that has `write:packages` (`gh auth refresh -h github.com -s write:packages`):

  ```bash
  cd packages/ui
  printf '//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}\n' > /tmp/divine-npmrc
  NODE_AUTH_TOKEN=$(gh auth token) npm publish --userconfig /tmp/divine-npmrc
  ```

`prepack` builds `dist/` first. Check what ships with `npm pack --dry-run`.

To see what's on the registry: `gh api /orgs/DivineSkins/packages/npm/ui/versions --jq '.[].name'` (needs `read:packages`). On 2026-10-25 the registry had **0.1.0** (published 2026-10-24) and the repo was at **0.2.0**, not yet published. Apps in other repos on 0.1.0 may miss components and variants added since; check the commit log of `packages/ui` before relying on one.
