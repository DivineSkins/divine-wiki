/**
 * Divine Skins preset for Tailwind CSS v3, built from tokens/tokens.json.
 *
 *   // tailwind.config.js
 *   module.exports = {
 *     presets: [require("@divineskins/ui/tailwind-preset")],
 *     content: ["./src/**\/*.{ts,tsx}", "./node_modules/@divineskins/ui/dist/**\/*.js"],
 *   }
 *
 * Every token is namespaced `divine-*` (bg-divine-surface, text-divine-body,
 * rounded-divine-xl) so it never collides with Tailwind's own scale or an app's
 * legacy names. The preset has no plugins and no base styles: it only adds theme
 * values, so dropping it into an existing config changes nothing until a class
 * uses it.
 */
const tokens = require("./tokens/tokens.json")

const withoutMeta = (group) =>
  Object.fromEntries(Object.entries(group).filter(([key]) => !key.startsWith("$")))

const prefixed = (group) =>
  Object.fromEntries(Object.entries(withoutMeta(group)).map(([key, value]) => [`divine-${key}`, value]))

const themeColors = withoutMeta(tokens.themeColors)

/**
 * A theme color reads `--divine-<name>` and falls back to the token, so nothing
 * needs defining for the default purple and a theme can swap it at runtime.
 * color-mix keeps Tailwind's opacity modifiers working on a var() color
 * (`bg-divine-accent/10`, `ring-divine-accent/50`).
 */
const themeColor = (name) =>
  `color-mix(in srgb, var(--divine-${name}, ${themeColors[name]}) calc(<alpha-value> * 100%), transparent)`

const accentAt = (percent) =>
  `color-mix(in srgb, var(--divine-accent, ${themeColors.accent}) ${percent}%, transparent)`

// The CTA glow's falloff, sampled from a 44px blur at 55%: [px past the element's edge, % of the
// accent]. It runs out to 64px and eases to nothing, because a glow that stops short reads as a
// dark ring around it, more so while it moves. CTA_GLOW_HALF is the half height of a 44px
// element's glow box; the 22px inside the edge is under the element's own fill.
// At the very bottom a browser rounds a dim channel (the accent's green) to nothing while still
// dimming what is behind it, which draws a dark ring around the glow. So the tail gets just
// enough white to cancel that loss: a little under 2%, and pure white for the last 0.3%, where
// the rounding leaves one level in and one level out. More than this reads as a gray band.
const CTA_GLOW_HALF = 86
const CTA_GLOW_FALLOFF = [[0, 27.5], [8, 19.8], [16, 12.8], [24, 7.6], [32, 4], [40, 1.9], [48, 0.8], [56, 0.3]]
const ctaGlowAt = (edge) => (edge + 22) / CTA_GLOW_HALF
const ctaGlowColor = (percent) => {
  if (percent >= 2) return accentAt(percent)
  if (percent < 0.5) return `color-mix(in srgb, white ${percent}%, transparent)`
  return `color-mix(in srgb, color-mix(in srgb, var(--divine-accent, ${themeColors.accent}) 78%, white) ${percent}%, transparent)`
}
const CTA_GLOW_STOPS = [
  `${accentAt(55)} 0%`,
  ...CTA_GLOW_FALLOFF.map(([edge, percent]) => `${ctaGlowColor(percent)} ${(ctaGlowAt(edge) * 100).toFixed(1)}%`),
  "transparent 100%",
].join(", ")
// The same falloff from the top of the bar to its bottom.
const CTA_GLOW_BAR_STOPS = [
  "transparent 0%",
  ...[...CTA_GLOW_FALLOFF].reverse().map(([edge, percent]) => `${ctaGlowColor(percent)} ${((1 - ctaGlowAt(edge)) * 50).toFixed(1)}%`),
  `${accentAt(55)} 50%`,
  ...CTA_GLOW_FALLOFF.map(([edge, percent]) => `${ctaGlowColor(percent)} ${((1 + ctaGlowAt(edge)) * 50).toFixed(1)}%`),
  "transparent 100%",
].join(", ")

/** @type {import('tailwindcss').Config} */
module.exports = {
  theme: {
    extend: {
      colors: {
        divine: {
          ...tokens.colors,
          accent: {
            DEFAULT: themeColor("accent"),
            hover: themeColor("accent-hover"),
          },
          highlight: themeColor("highlight"),
          "icon-accent": themeColor("icon-accent"),
        },
      },
      fontFamily: withoutMeta(tokens.fontFamily),
      fontSize: prefixed(tokens.fontSize),
      spacing: prefixed(tokens.spacing),
      borderRadius: prefixed(tokens.borderRadius),
      boxShadow: {
        ...prefixed(tokens.boxShadow),
        // The primary button's bloom: a top highlight plus a 44px glow in the theme accent.
        "divine-cta": `inset 0px 1px 1px 0px rgba(255, 255, 255, 0.35), 0px 0px 44px 0px ${accentAt(55)}`,
        // The bloom's highlight alone, for CTA_BLOOM_CLASS (src/lib/bloom.ts), which paints
        // its glow with bg-divine-cta-glow below.
        "divine-cta-highlight": "inset 0px 1px 1px 0px rgba(255, 255, 255, 0.35)",
        // The same bloom turned down for compact controls (the small segmented thumb).
        "divine-cta-sm": `inset 0px 1px 1px 0px rgba(255, 255, 255, 0.3), 0px 0px 18px 0px ${accentAt(45)}`,
      },
      backgroundImage: {
        ...prefixed(tokens.backgroundImage),
        // The featured card's frame: a panel fill over a gold-to-highlight border, the
        // highlight following the theme. Pair with border-transparent bg-origin-border
        // [background-clip:padding-box,border-box]. Built here rather than from Tailwind's
        // from-/to- stops, which v4 only fills alongside a bg-linear-* class.
        "divine-frame": `linear-gradient(${tokens.colors.panel}, ${tokens.colors.panel}), linear-gradient(180deg, ${tokens.colors.secondary.DEFAULT} 0%, var(--divine-highlight, ${themeColors.highlight}) 40%)`,
        // The CTA bloom's glow as gradients, in three tiles: two caps and the bar between them,
        // which make a pill's halo. CTA_BLOOM_CLASS sizes them.
        "divine-cta-glow": [
          `radial-gradient(ellipse 100% 50% at 100% 50%, ${CTA_GLOW_STOPS})`,
          `radial-gradient(ellipse 100% 50% at 0% 50%, ${CTA_GLOW_STOPS})`,
          `linear-gradient(180deg, ${CTA_GLOW_BAR_STOPS})`,
        ].join(", "),
        // The Progress fill: the theme accent running to the highlight (the site's UploadMeter).
        "divine-progress": `linear-gradient(90deg, var(--divine-accent, ${themeColors.accent}), var(--divine-highlight, ${themeColors.highlight}))`,
      },
      // Overlay motion for dialogs, popovers and menus. `scale` (not transform)
      // so it composes with the -50% translate that centres a dialog.
      keyframes: {
        "divine-fade-in": { from: { opacity: "0" }, to: { opacity: "1" } },
        "divine-fade-out": { from: { opacity: "1" }, to: { opacity: "0" } },
        "divine-pop-in": { from: { opacity: "0", scale: "0.96" }, to: { opacity: "1", scale: "1" } },
        "divine-pop-out": { from: { opacity: "1", scale: "1" }, to: { opacity: "0", scale: "0.96" } },
        "divine-check-ripple": { from: { opacity: "0.45", scale: "1" }, to: { opacity: "0", scale: "2.2" } },
        // A quarter-wide sheen, from fully off the left of the fill to fully off the right.
        "divine-progress-sheen": { from: { transform: "translateX(-100%)" }, to: { transform: "translateX(400%)" } },
      },
      // Damped springs sampled over 18 steps, for transitions of about 420ms. A browser
      // without linear() falls back to the default ease. The bouncy one peaks at 116%,
      // the other at 108%.
      transitionTimingFunction: {
        "divine-spring":
          "linear(0, 0.105, 0.332, 0.579, 0.79, 0.942, 1.033, 1.075, 1.083, 1.071, 1.052, 1.031, 1.015, 1.003, 0.996, 0.993, 0.993, 0.994, 1)",
        "divine-spring-bouncy":
          "linear(0, 0.147, 0.456, 0.77, 1.002, 1.129, 1.163, 1.138, 1.088, 1.037, 0.999, 0.979, 0.973, 0.978, 0.986, 0.994, 1, 1.003, 1)",
      },
      animation: {
        "divine-fade-in": "divine-fade-in 150ms ease-out",
        "divine-fade-out": "divine-fade-out 120ms ease-in",
        "divine-pop-in": "divine-pop-in 180ms cubic-bezier(0.22, 1, 0.36, 1)",
        "divine-pop-out": "divine-pop-out 120ms ease-in",
        "divine-check-ripple": "divine-check-ripple 500ms cubic-bezier(0.22, 1, 0.36, 1)",
        "divine-progress-sheen": "divine-progress-sheen 1.6s ease-in-out infinite",
      },
    },
  },
}
