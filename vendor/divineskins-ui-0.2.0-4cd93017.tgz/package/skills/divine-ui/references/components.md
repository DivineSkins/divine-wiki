# Components

Everything imports from `@divineskins/ui`. Every component forwards its ref, takes `className` (merged last, so it wins) and the props of the element or Radix part it renders. Icons are `lucide-react`, passed bare: components size them. See every variant live with `npm run dev` in `packages/ui` (add `?theme=halloween` for the seasonal accent).

## Actions

### Button

`Button`, `buttonVariants`, `ButtonProps`. Renders a `<button type="button">` (pass `type="submit"` to submit a form), or its child with `asChild`.

| Prop | Values | Default |
|------|--------|---------|
| `variant` | `primary` solid accent + CTA bloom (dropped while disabled) · `secondary` white/10 · `ghost` muted text, white/10 on hover · `ghost-danger` ghost that turns red on hover · `field` a toolbar control with the field's fill, rim and 12px corners · `danger` red tint · `danger-solid` red fill (the final confirm) · `success` green tint (a good state you can act on, like Mark fixed) · `link` highlight text, underline on hover | `primary` |
| `size` | `sm` 36px · `md` 40px · `lg` 44px · `icon-sm` 32px circle · `icon` 44px circle | `lg` |
| `asChild` | render the child (a router `Link`, an `<a>`) with the button's styles | `false` |

```tsx
<Button><Download /> Install</Button>
<Button variant="secondary">Details</Button>
<Button variant="ghost" size="icon-sm" aria-label="Edit"><Pencil /></Button>
<Button asChild variant="secondary"><a href="/mods">Browse mods</a></Button>
```

One primary per view. Icon-only buttons need an `aria-label`. Every button sinks to 95% while pressed and springs back on release, off under reduced motion. A button that is working (`disabled` with a `Spinner tone="current"`) should also get `aria-busy`, which keeps it at 80% instead of fading to 50%. `buttonVariants({ variant, size })` gives the classes for something that can't be a `Button`.

Icons inside are sized 16px by the button's `[&_svg]:size-4`, which beats a `size-5` class on the icon itself. For a bigger icon put `[&_svg]:size-5` on the `Button`, or `!size-5` on the one icon. The button already spaces its children with `gap-2`, so icons need no `mr-2`. With `asChild`, put every class on the `Button`, not on the child: Radix joins the two class lists without merging them, so a child class can't override a variant class reliably.

### IconTile

`IconTile`, `iconTileVariants`, `IconTileProps`, `IconTileTone`. A small raised square holding one icon; the size sets the icon size.

| Prop | Values | Default |
|------|--------|---------|
| `size` | `xs` 28 · `sm` 32 · `md` 40 · `lg` 44 · `xl` 48 · `2xl` 56 (px) | `lg` |
| `tone` | `brand` (theme icon accent) · `gold` (Divine+ and money only) · `success` · `warning` · `danger` (status meaning only) · `muted` | `brand` |

```tsx
<IconTile tone="gold" size="md"><Crown /></IconTile>
```

Use it for section headings, feature and stat cards, dialog headers. Never hand-roll a tinted square.

### Chip

`Chip`, `chipVariants`, `ChipProps`. A pressable pill for filters and multi-pick, the interactive sibling of `Badge`, with no rim: at rest the surface fill with muted text, and on hover the fill rises and the text lifts; selected, a 10% accent fill and highlight text. Renders a `<button type="button">`.

| Prop | Values | Default |
|------|--------|---------|
| `selected` | picked: sets `data-state="on" \| "off"`, and `aria-pressed` unless you pass a `role` | `false` |
| `size` | `sm` 32px, 12px text · `md` 36px, 13px text | `md` |
| `role` | inside a composite widget (`tab`, `radio`, `option`, `checkbox`): the chip drops `aria-pressed` and you set `aria-selected` / `aria-checked` | |

```tsx
<Chip size="sm" selected={cumulative} onClick={() => setCumulative((on) => !on)}><Sigma /> Cumulative</Chip>
<div role="tablist" aria-label="Filter changelog">
  <Chip role="tab" aria-selected={isActive} selected={isActive} onClick={() => setView(view)}>{view.label}</Chip>
</div>
<Link to={catalogPath(game)} className={chipVariants()}>{game.name}</Link>
```

A disabled chip fades to 50% but keeps its pointer events, so a `title` can say why it is off. `chipVariants({ size, selected })` gives the classes for a link (hover is gated on `:not(:disabled)`, so it works on an `<a>`). Pick one of two or three that apply at once is `SegmentedControl`; a static label is `Badge`.

## Display

### Badge

`Badge`, `badgeVariants`, `BadgeProps`, `BadgeTone`. A pill: 10% fill, no rim.

| Prop | Values | Default |
|------|--------|---------|
| `tone` | `accent` · `gold` · `success` · `warning` · `danger` · `neutral` (white text) · `muted` | `accent` |
| `size` | `sm` 20px tall, 10px text · `md` 28px tall, 11px text | `sm` |
| `caps` | uppercase with tracking, for short status words (`ARCHIVED`, `DRAFT`) | `false` |

```tsx
<Badge tone="success" caps>Paid out</Badge>
<Badge tone="neutral" size="md">12 files</Badge>
```

### Card

`Card`, `CardHeader`, `CardTitle` (h3), `CardDescription`, `cardVariants`, `CardProps`. Panel fill, faint border, 12px corners.

| Prop | Values | Default |
|------|--------|---------|
| `variant` | `default` · `interactive` (the rim warms on hover; for clickable cards) · `featured` (gold to highlight gradient frame; follows the theme) | `default` |
| `padding` | `none` · `sm` 16px · `md` 20px · `lg` 24px | `md` |

```tsx
<Card variant="featured">
  <CardHeader>
    <CardTitle>Divine+</CardTitle>
    <CardDescription>Support the creators you use.</CardDescription>
  </CardHeader>
</Card>
```

`featured` is the brand's signature frame: at most one per screen. Don't nest cards.

### Separator

`Separator`, `separatorVariants`, `SeparatorProps`. A faint 1px line. `orientation`: `horizontal` (default) or `vertical`. Decorative by default (hidden from screen readers); pass `decorative={false}` when it separates real content groups.

### Skeleton

`Skeleton`. White at 6% with a pulse, `aria-hidden`. Size it with classes: `<Skeleton className="h-4 w-32 rounded-md" />`. It works on any surface.

### EmptyState

`EmptyState`, `EmptyStateProps`. A centered IconTile, title, description and optional action, with no frame of its own.

| Prop | Type |
|------|------|
| `icon` | a bare lucide icon |
| `iconTone` | an `IconTileTone`, default `brand` |
| `title` | required |
| `titleAs` | the title's element, `h2` · `h3` · `h4` · `p`, to fit the page outline; default `h3` at `md`, `p` at `sm` (the panel around a small block already has the heading) |
| `description`, `action` | optional (`action` is usually a `Button`) |
| `size` | `md` (default): `2xl` tile, 18px title, 14px line, `px-6 py-12`, for a page section, tab or list. `sm`: default (`lg`) tile, 14px title, 12px line up to 280px wide, `px-4` and no vertical padding, for a small panel (a chart card, a side list, a table body); give it its height with `className` (`h-40`, `py-10`) |

```tsx
<Card><EmptyState icon={<FolderOpen />} title="No mods yet" description="Your uploads show up here." action={<Button>Upload a mod</Button>} /></Card>

// A list or tab with no card of its own: frame it and keep the list's height.
<Card padding="none" className="flex min-h-[280px] items-center justify-center"><EmptyState icon={<Plus />} title="No drafts" /></Card>

// Inside a chart card that already has its header.
<EmptyState size="sm" icon={<PieChart />} title="No data yet" description="Stats show up once players start interacting with your mods." className="h-40" />
```

### Avatar

`Avatar`, `avatarVariants`, `AvatarProps`. A round picture: raised fill, faint rim. With no `src`, or when the image fails, it shows the initials of `name` in the theme highlight, and with no name a muted person icon.

| Prop | Values | Default |
|------|--------|---------|
| `size` | `xs` 24 · `sm` 32 · `md` 40 · `lg` 56 · `xl` 80 (px) | `md` |
| `src`, `name` | the image URL; the name the initials come from | |
| `alt` | names the picture; leave empty when a name sits next to it | `""` |
| `fallback` | replaces initials and icon (`<HandHeart />` for an anonymous supporter) | |
| `imageProps` | passed to the `<img>` (`referrerPolicy="no-referrer"` for Google photos) | |

### DivinePlusBadge

`DivinePlusBadge`, `divinePlusBadgeVariants`, `DivinePlusBadgeProps`. The Divine+ subscriber pill: obsidian fill, highlight-to-accent ring and glow, gradient "Divine+", a sheen every 4.5s (off under reduced motion, or with `animated={false}`). `size`: `sm` (menus, default), `md` (profile pages), `lg`. The package ships no images: pass the winged logo as `logoSrc` (on the website `/static/media/branding/divine-plus-logo.webp`), or it renders text only. Divine+ moments only.

### Table

`Table`, `TableHeader`, `TableBody`, `TableRow`, `TableHead`, `TableCell`, `TableCaption`. The creator analytics look: 10px letter-spaced muted column labels, hairline rows, a row that lifts on hover (`data-state="selected"` tints it with the accent), 12px cell padding with 20px at the row's ends. `TableHead` sorts with `onSort` and `sort` (`ascending` · `descending` · `none`): the label becomes a button and the head sets `aria-sort`; your handler reorders the rows. Scrolls sideways in its own wrapper. No frame: put it in a `Card padding="none"`.

## Feedback

### Alert

`Alert`, `alertVariants`, `AlertProps`, `AlertTone`. An inline notice in the page, not a toast: a neutral box with no rim, the tone only in its `IconTile`. With `icon={null}` nothing shows the tone, so keep that for neutral notices.

| Prop | Values | Default |
|------|--------|---------|
| `tone` | `info` (theme accent) · `success` · `warning` · `danger` | `info` |
| `title` | bold line; the description then drops to a muted 12px line | |
| `description` / `children` | the text | |
| `icon` | a bare lucide icon to replace the tone's; `null` or `false` for none | the tone's |
| `action` | usually one `Button size="sm"`, at the end of the row | |

`danger` gets `role="alert"`, the rest `role="status"`; pass `role="none"` for a notice that is there from page load.

```tsx
<Alert tone="warning" icon={<PauseCircle />}>Downloads for Deadlock are paused right now. Check back soon.</Alert>
<Alert tone="danger" title="Couldn't start the downloads." description="Try again in a moment." action={<Button size="sm" variant="secondary">Try again</Button>} />
```

### Spinner

`Spinner`, `spinnerVariants`, `SpinnerProps`. A rounded arc turning on a faint track, `role="status"` with a hidden `label` (default "Loading"); still under reduced motion. `size`: `xs` 14 · `sm` 16 · `md` 24 (default) · `lg` 32 · `xl` 48 (px). `tone`: `accent` (theme highlight, default) · `muted` · `current` (inside a Button).

### Progress

`Progress`, `progressVariants`, `ProgressProps`. The upload bar: faint track, a fill running from the accent to the highlight, with a light sweep until it completes. `value` 0 to 100; leave it out for indeterminate (full width, with the sweep). `size`: `sm` 4px · `md` 6px with a soft glow under the fill (default). `tone`: `accent` · `success`. Give it an `aria-label`.

## Forms

Fields are 44px tall with 12px corners on the `divine-surface` fill with the `divine-border-control` rim (`FIELD_CONTROL_CLASS`). Hover raises the fill and warms the rim to subtle. The border turns accent at 60% on focus and red when `aria-invalid`; an invalid field turns accent again while focused, so the user sees where they are typing (as the upload flow does).

### Input, Textarea, Label

`Input`, `inputVariants`, `InputProps`: `size` is `md` (44px, forms; the default) or `sm` (36px, the search box at the top of a menu). Inside a `Popover`, `Select` or `DropdownMenu` panel a field takes a white 4% tint so it shows on the panel's matching fill. The native `size` attribute is not available. `Textarea`, `TextareaProps`: same recipe, 96px minimum, not resizable, so set `rows` for height. `Label`, `LabelProps`: a plain `<label>`; you rarely need it directly because `Field` renders one.

### Field

`Field`, `FieldProps`, `FieldContext`. Label + one control + one line of help, wired for screen readers.

| Prop | Type |
|------|------|
| `label` | the label text |
| `optional` | adds a muted "Optional" after the label |
| `help` | beside the label, outside the `<label>`: an info button |
| `aside` | right-aligned in the label row: a counter or other meta |
| `hint` | a line under the control |
| `error` | replaces the hint while set, and marks the control invalid |
| `children` | exactly one control |

```tsx
<Field label="Version" hint="Like 1.2.0." error={versionError}>
  <Input value={version} onChange={(e) => setVersion(e.target.value)} />
</Field>
<Field label="Description" optional aside={`${text.length}/500`}>
  <Textarea value={text} onChange={(e) => setText(e.target.value)} />
</Field>
```

It sets the control's `id` (keeping one you passed), `aria-describedby` and `aria-invalid`, and announces an error when it appears (`role="alert"`). A `Select` inside a `Field` is wired through context, on its `SelectTrigger`.

### Checkbox

`Checkbox`, `CheckboxProps` (Radix). 18px on a white tint with no rim. Checking springs in the accent fill, sends one ripple and draws the tick; `checked="indeterminate"` draws a dash. The ripple only plays once the user has toggled it, never on page load. Pair it with a `<label htmlFor>` next to it.

```tsx
<div className="flex items-center gap-2.5">
  <Checkbox id="ai" checked={noAi} onCheckedChange={(v) => setNoAi(v === true)} />
  <label htmlFor="ai" className="text-sm">No AI-generated assets</label>
</div>
```

### Switch

`Switch`, `SwitchProps`. Off is a muted thumb on a white tint. On springs the thumb across, grows the accent behind it and lights the thumb white. A `button role="switch"`, controlled (`checked` + `onCheckedChange`) or uncontrolled (`defaultChecked`). For settings that apply at once; give it a `<label htmlFor>` or an `aria-label`. With a `name` it adds a hidden checkbox, so native form posts include it (`value` defaults to `on`).

### Select

`Select`, `SelectTrigger`, `SelectValue`, `SelectContent`, `SelectItem`, `SelectGroup`, `SelectLabel`, `SelectSeparator`, `SelectScrollUpButton`, `SelectScrollDownButton` (Radix). The trigger is the field recipe with a chevron that turns when open; the list is the menu panel, as wide as the trigger. Selected items get the highlight tint and a check.

```tsx
<Field label="Game">
  <Select value={game} onValueChange={setGame}>
    <SelectTrigger><SelectValue placeholder="Pick one" /></SelectTrigger>
    <SelectContent>
      <SelectItem value="lol">League of Legends</SelectItem>
      <SelectItem value="deadlock">Deadlock</SelectItem>
    </SelectContent>
  </Select>
</Field>
```

`SelectLabel` must sit inside a `SelectGroup`. For a searchable or multi-pick picker, build it from `Popover` + `PickerTrigger` + `Input size="sm"` + `PopoverItem` instead (below).

### PickerTrigger, PopoverItem

`PickerTrigger`, `PickerTriggerProps`: the `SelectTrigger` look (44px field, chevron that turns while open) as a plain `<button>`, for a picker built on `Popover`. Children are the current value; `placeholder` shows muted while there is none. Put it in `<PopoverTrigger asChild>` (that sets the `data-state` the rim and chevron follow); inside a `Field` it takes the field's id and aria wiring.

`PopoverItem`, `PopoverItemProps`: a pickable row in a `Popover` list, the menu row lit on hover and keyboard focus. `selected` gives the checked tint and a trailing check (`indicator={false}` drops the check, e.g. for multi-pick rows that show a checkbox). It renders `<button type="button">`; set the aria state yourself (`aria-pressed` for toggles, or `role="option"` + `aria-selected` inside a `role="listbox"`).

```tsx
<Popover open={open} onOpenChange={setOpen}>
  <PopoverTrigger asChild>
    <PickerTrigger placeholder="Pick a champion">{champion}</PickerTrigger>
  </PopoverTrigger>
  <PopoverContent align="start" className="w-[var(--radix-popover-trigger-width)]">
    <Input size="sm" className="mb-1.5" placeholder="Search champions" value={query} onChange={(e) => setQuery(e.target.value)} />
    {matches.map((name) => (
      <PopoverItem key={name} selected={name === champion} aria-pressed={name === champion} onClick={() => pick(name)}>
        {name}
      </PopoverItem>
    ))}
  </PopoverContent>
</Popover>
```

`menuPanelClassName(className?)` and `menuItemClassName({ selected?, className? })` give the panel and row classes for a menu that can't be Radix (the navbar's hover menus). Prefer `DropdownMenu`, `Select` or `Popover` + `PopoverItem` wherever they fit.

### SearchInput

`SearchInput`, `SearchInputProps`. The Input recipe, a leading search icon that warms to the icon accent on focus and a clear pill once there is text; Escape clears too. Same `size` as Input. Controlled (`value` + `onValueChange` or `onChange`) or uncontrolled (`defaultValue`); clearing fires a real `onChange` with `""`. `className` goes on the wrapper (width), `inputClassName` on the field, the ref on the `<input>`. `trailing` holds a control inside the field on the right, such as a filter dropdown; the field measures it and keeps its text and clear pill short of it. `clearLabel` defaults to "Clear search".

### SegmentedControl

`SegmentedControl`, `segmentedControlVariants`, `SegmentedControlProps`, `SegmentedControlOption`. The Show / Hide and Yes / No pill toggle: equal-width options, the pick a sliding accent thumb. A `radiogroup`: arrow keys and Home / End move and pick. Name it with `aria-label`.

| Prop | Values | Default |
|------|--------|---------|
| `options` | `{ value, label, disabled?, "aria-controls"? }[]` (typed: `onValueChange` hands back the union); `aria-controls` names what the option reveals, such as an "Other" option's amount field | |
| `value` / `defaultValue` / `onValueChange` | `value={null}` shows nothing picked (an unanswered Yes / No) | |
| `size` | `sm` 28px, catalog preferences · `md` 36px, creator forms. Both use the small glow, dropped while disabled | `sm` |
| `disabled`, `name` | whole control off; `name` posts the pick with a form | |

```tsx
<SegmentedControl aria-label="18+ mods" options={[{ value: "show", label: "Show" }, { value: "hide", label: "Hide" }]} value={adult} onValueChange={setAdult} />
```

For 2 or 3 short choices that apply at once, or a row of short amounts with an "Other" (the `/support` amount picker: `className="w-full"`). More than that, use `Select`.

## Overlays

`Popover`, `Select` and `DropdownMenu` panels share one recipe: `divine-surface-field` fill with no border, 12px corners, `shadow-divine-panel`, a quick fade and scale in. Rows light up with white at 5%. They portal to `<body>`, so they work inside dialogs and scrolling containers. `Dialog` keeps the panel fill and a faint border, with 16px corners and 28px padding.

### Dialog

`Dialog`, `DialogTrigger`, `DialogContent`, `DialogHeader`, `DialogFooter`, `DialogTitle`, `DialogDescription`, `DialogClose`, `DialogPortal`, `DialogOverlay` (Radix). `DialogContent` brings the dimmed overlay, scrolls when taller than the screen, and has a close button (`hideCloseButton` removes it; `overlayClassName` styles the overlay).

```tsx
<Dialog>
  <DialogTrigger asChild><Button variant="danger">Delete mod</Button></DialogTrigger>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Delete this mod?</DialogTitle>
      <DialogDescription>Its downloads and comments go with it.</DialogDescription>
    </DialogHeader>
    <DialogFooter>
      <DialogClose asChild><Button variant="secondary">Keep it</Button></DialogClose>
      <Button variant="danger-solid">Delete</Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

Every dialog needs a `DialogTitle` (Radix warns otherwise; wrap it in a visually hidden element if the design has no visible title). Give it a `DialogDescription` too, or pass `aria-describedby={undefined}` to `DialogContent` when there is none (Radix warns in dev otherwise). To describe it with a block of your own (a warning box, a list), wrap that block in `<DialogDescription asChild>`.

A dialog opened from state (`open` + `onOpenChange`, no `DialogTrigger`) hands focus back on close to whatever had it when the dialog opened, as a trigger would. Your own `onCloseAutoFocus` runs first; call `preventDefault()` in it to send focus somewhere else.

### DropdownMenu

`DropdownMenu`, `DropdownMenuTrigger`, `DropdownMenuContent` (min 200px), `DropdownMenuItem` (`tone="danger"` for destructive rows), `DropdownMenuCheckboxItem`, `DropdownMenuRadioGroup`, `DropdownMenuRadioItem`, `DropdownMenuLabel`, `DropdownMenuSeparator`, `DropdownMenuGroup`, `DropdownMenuPortal`, `DropdownMenuSub`, `DropdownMenuSubTrigger`, `DropdownMenuSubContent` (Radix). For actions. To pick a value, use `Select`.

```tsx
<DropdownMenu>
  <DropdownMenuTrigger asChild><Button variant="ghost" size="icon-sm" aria-label="More"><MoreHorizontal /></Button></DropdownMenuTrigger>
  <DropdownMenuContent align="end">
    <DropdownMenuItem><Pencil /> Edit</DropdownMenuItem>
    <DropdownMenuSeparator />
    <DropdownMenuItem tone="danger"><Trash2 /> Delete</DropdownMenuItem>
  </DropdownMenuContent>
</DropdownMenu>
```

### Popover

`Popover`, `PopoverTrigger`, `PopoverContent` (288px wide, 6px inset), `PopoverAnchor`, `PopoverClose` (Radix). For free-form floating content: filter panels, pickers with search. Pad the content to fit (`className="p-4"`).

### Tooltip

`Tooltip`, `TooltipTrigger`, `TooltipContent` (with an arrow, max 320px), `TooltipProvider`. Tooltips open after 150ms. A lone `Tooltip` brings its own provider; wrap the app in one `TooltipProvider` so moving between neighbouring tooltips opens them at once. Short explanations of an icon or a truncated label, never essential information (touch screens never see it).

```tsx
<Tooltip>
  <TooltipTrigger asChild><Button variant="ghost" size="icon-sm" aria-label="About 18+"><Info /></Button></TooltipTrigger>
  <TooltipContent>Only the files can be 18+.</TooltipContent>
</Tooltip>
```

## Navigation

### Tabs

`Tabs`, `TabsList`, `TabsTrigger`, `TabsContent`, `TabsCount`, `tabsListVariants`, `tabsTriggerVariants` (Radix). The `variant` goes on `TabsList` and its triggers inherit it. `TabsCount` is a tab's number after the label: a small rounded square, muted, that takes the accent while its tab is active.

| `variant` | Look | Use |
|-----------|------|-----|
| `pill` (default) | segmented pills, with a solid accent thumb and glow that slides and stretches to the active one | 2 to 4 views of the same data (All time / This month) |
| `underline` | text tabs with no side padding, so the first label lines up with the content, over a hairline. A label-wide highlight bar slides to the active one, and a fainter bar fades in on hover | sections of a page (Overview / Files / Comments) |

```tsx
<Tabs defaultValue="overview">
  <TabsList variant="underline">
    <TabsTrigger value="overview">Overview</TabsTrigger>
    <TabsTrigger value="files">Files</TabsTrigger>
  </TabsList>
  <TabsContent value="overview">...</TabsContent>
</Tabs>
```

### Pagination

`Pagination`, `paginationItemVariants`, `PaginationProps`. Previous, page numbers with ellipses, next, as round buttons with no rim. The current page is the solid accent and pops in where it lands. Controlled and router-free: `page` and `pageCount` counted from 1, `onPageChange(page)`; it renders buttons, so the caller decides whether that changes a URL. `size`: `md` 40px panel circles (catalog, default) · `sm` 32px ghost circles (tables). `siblingCount` pages either side of the current one (default 1), `disabled` while the next page loads. Renders nothing for a single page. The current page has `aria-current="page"`.

```tsx
<Pagination page={page} pageCount={totalPages} onPageChange={setPage} className="justify-end" />
```

### Accordion

`Accordion`, `AccordionItem`, `AccordionTrigger`, `AccordionContent`. The FAQ look, Radix's API without Radix: `type="single"` (with `collapsible` to let the open item close, off by default as in Radix) or `type="multiple"`, `value` / `defaultValue` / `onValueChange`, `disabled` on the root or an item. Triggers sit in an `h3`, Up / Down move between them. Content eases open with no measuring and stays mounted.

```tsx
<Accordion type="single" collapsible>
  <AccordionItem value="install">
    <AccordionTrigger>How do I install a mod?</AccordionTrigger>
    <AccordionContent>Get Celestial and press Install.</AccordionContent>
  </AccordionItem>
</Accordion>
```

## Utilities

- `cn(...classes)`: clsx + tailwind-merge configured for the `divine-*` tokens. Use it to merge conditional classes in your own components.
- `tokens`: the raw `tokens.json` object, for inline styles, canvas and charts.
