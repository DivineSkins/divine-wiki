# Divine tokens

Source of truth: `packages/ui/tokens/tokens.json`. Every token is a Tailwind class through the preset (`bg-divine-surface`, `text-divine-body`, `p-divine-x`, `rounded-divine-xl`, `shadow-divine-card`, `bg-divine-tile`) and a CSS variable in `tokens.css` (`--divine-surface`, `--divine-text-body`, `--divine-space-x`, `--divine-radius-xl`, `--divine-shadow-card`, `--divine-gradient-tile`). In TypeScript: `import { tokens } from "@divineskins/ui"`.

## Surfaces: three tiers, dark only

Build every screen from void, then surface, then border. Nothing lighter than `divine-surface-raised` as a fill.

| Token | Value | Use |
|-------|-------|-----|
| `divine-bg` | `#0E0D14` | The void: page background |
| `divine-overlay` | `#0B0A0F` | Dialog backdrop (at 80%) |
| `divine-track` | `#0F0E15` | Segmented control track, a step under the void |
| `divine-panel` | `#121119` | Floating panels: menus, popovers, select lists, cards |
| `divine-surface` | `#15141C` | Text fields, select triggers, accordions, `field` buttons, raised blocks |
| `divine-surface-field` | `#18171F` | Menu and popover panels, alerts |
| `divine-surface-raised` | `#1A1922` | Hover and open state of a surface (field hover, open select) |
| `divine-tooltip` | `#18171F` | Tooltip fill, the same color as menu and popover panels |
| `divine-border` | `#363242` | Interactive border, field hover |
| `divine-border-subtle` | `#25222F` | Field border on hover |
| `divine-border-control` | `#1F1D29` | Field border at rest |
| `divine-border-faint` | `#191722` | Panel and menu hairlines |
| `divine-border-tile` | `#17161C` | Icon tile edge |

White overlays (`bg-white/10`, `bg-white/20`) are the secondary button and hover fill, not a surface.

## Brand and status colors

| Token | Value | Use |
|-------|-------|-----|
| `divine-primary` | `#783CB5` | The fixed brand purple: logo, brand art. Not for controls (use `divine-accent`) |
| `divine-primary-hover` | `#8B4DD4` | |
| `divine-primary-light` | `#C084FC` | Soft purple |
| `divine-primary-lilac` | `#B472FF` | Legacy gradient start |
| `divine-primary-50` / `-25` / `-15` | purple at 50/25/15% | Tints |
| `divine-secondary` | `#ECB96A` | Gold. Prestige only: Divine+, earnings, premium borders |
| `divine-secondary-50` / `-25` / `-15` | gold at 50/25/15% | |
| `divine-text` | `#E4E4E7` | Body and heading text |
| `divine-text-muted` (= `divine-muted`) | `#8B8D98` | Meta text, captions, icons at rest. Never long body copy |
| `divine-text-muted-50` / `-25` | muted at 50/25% | Placeholders, disabled hints |
| `divine-success` | `#22C55E` | `-50` / `-25` / `-10` tints |
| `divine-error` | `#EF4444` | `-50` / `-25` / `-10` tints |
| `divine-warning` | `#FACC15` | `-50` / `-25` / `-10` tints |

Opacity modifiers work on every color: `bg-divine-error/15`, `border-divine-secondary/40`.

## Theme colors (re-skinnable)

These read a CSS variable and fall back to the purple, so a theme can swap them at runtime (the website's Halloween theme turns them orange). Use them for anything interactive: buttons, focus rings, checked states, active tabs, links, selected menu rows, brand icons.

| Class | Variable | Default | Use |
|-------|----------|---------|-----|
| `divine-accent` | `--divine-accent` | `#783CB5` | Primary buttons, checked fills, active indicators, focus ring (`ring-divine-accent/50`) |
| `divine-accent-hover` | `--divine-accent-hover` | `#8B4DD4` | Hover of an accent fill |
| `divine-highlight` | `--divine-highlight` | `#C084FC` | Links, selected text, soft emphasis |
| `divine-icon-accent` | `--divine-icon-accent` | `#AB69EF` | Brand-toned icons (`IconTile tone="brand"`) |

They take opacity modifiers too (`bg-divine-accent/10`). Override on any ancestor: `--divine-accent: #E56B17;`.

### Built-in themes

`themes.css` (import `@divineskins/ui/themes.css`) defines each theme in `tokens.json` under `themes`, switched by `data-divine-theme="<name>"` on `<html>` or any element:

| Theme | accent | accent-hover | highlight | icon-accent |
|-------|--------|--------------|-----------|-------------|
| `original` (the default) | `#783CB5` | `#8B4DD4` | `#C084FC` | `#AB69EF` |
| `halloween` | `#E56B17` | `#F07A26` | `#FB8732` | `#FB8732` |

## Type

Fonts: `font-manrope` (UI and body, the default), `font-poppins` (section headings), `font-inter` (tiny UI labels), `font-allison` (rare script accents).

| Class | Size / line height / weight |
|-------|------|
| `text-divine-hero` | 79px / 95px / 800 |
| `text-divine-section` | 30px / 29px / 700 |
| `text-divine-card-title` | 22px / 25px / 600 |
| `text-divine-body-lg` | 20px / 29px / 400 |
| `text-divine-body` | 16px / 24px / 400 |
| `text-divine-body-sm` | 13px / 20px / 400 |
| `text-divine-caption` | 12px / 16px / 500 |
| `text-divine-caption-sm` | 10px / 12px / 500 |

Uppercase only on tiny meta labels (10 to 12px, with tracking).

## Spacing, radius, elevation

Spacing (`p-`, `m-`, `gap-`...): `divine-sm` 2px · `divine-md` 4px · `divine-lg` 8px · `divine-x` 16px · `divine-x2` 24px · `divine-x3` 32px · `divine-x4` 40px · `divine-x5` 48px · `divine-x6` 56px · `divine-x7` 64px · `divine-x8` 72px · `divine-x9` 80px · `divine-x10` 88px · `divine-x11` 96px · `divine-x200` 200px. Tailwind's own scale works too; card padding is 16 to 24px.

Radius: `rounded-divine-sm` 2px · `-md` 4px · `-2md` 6px · `-lg` 8px · `-xl` 12px · `-2xl` 16px · `-3xl` 24px · `-2x` 32px · `-full` 999px. Fields and panels 12px (`rounded-xl`), cards 8 to 16px, never 24px+ on a card. Buttons and pills are always full (`rounded-full`).

Shadows:

| Class | Use |
|-------|-----|
| `shadow-divine-cta` | The primary button's bloom (top highlight + 44px accent glow). On the void a blurred glow's faint edge can darken what's behind it, so package components paint it as gradients instead (`bg-divine-cta-glow`, via `CTA_BLOOM_CLASS`). |
| `shadow-divine-cta-sm` | The same bloom turned down (18px), for compact controls |
| `shadow-divine-inset` | Just the top highlight, for a picked compact control without glow |
| `shadow-divine-panel` | Menus, popovers, select lists |
| `shadow-divine-dialog` | Dialogs |
| `shadow-divine-card` / `-card-hover` | Card rest and purple-tinted hover lift |
| `shadow-divine-tile` | Icon tile top highlight |
| `shadow-divine-thumb` | Switch thumb |
| `shadow-divine-glow` / `-glow-hover` | Legacy, admin only. Glow is surgical or absent |

Gradients (`bg-`): `divine-frame` (the featured card's frame: panel fill over a gold-to-highlight border that follows the theme; pair with `border-transparent bg-origin-border [background-clip:padding-box,border-box]`, or just use `Card variant="featured"`), `divine-card-border` (the static gold to lilac version of that motif), `divine-text-gradient` (lilac to purple, accent text), `divine-hr` (gold to purple, decorative lines), `divine-tile` (icon tile fill), `divine-btn` (legacy lilac-to-purple button; never on user-facing buttons).

## Motion

Overlays: `animate-divine-fade-in` / `-fade-out` (backdrops), `animate-divine-pop-in` / `-pop-out` (dialogs, menus; scales with the `scale` property, so it composes with centering transforms). Toggles: `ease-divine-spring` and `ease-divine-spring-bouncy` are damped springs for transitions of about 420ms, and `animate-divine-check-ripple` is the checkbox's ripple. Other product transitions stay in the 150 to 250ms range, and every animation has a reduced-motion path: gate state-driven ones with `motion-safe:` (`motion-safe:data-[state=open]:animate-divine-pop-in`), because `motion-reduce:animate-none` loses to a `data-[state]` class on specificity.
