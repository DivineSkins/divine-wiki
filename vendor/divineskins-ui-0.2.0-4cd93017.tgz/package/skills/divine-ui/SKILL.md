---
name: divine-ui
description: "Use when building or restyling UI in any Divine app (apps/web, the Celestial launcher, the Wiki, a new tool) with the shared Divine Skins design system: picking a component, variant or token, theming the accent (seasonal themes), setting the package up in an app, or adding a token or component to the package. Covers @divineskins/ui (packages/ui in the divine-skins monorepo): the design tokens, the Tailwind setup (divine-* classes, v4 CSS or v3 preset) and the React components, such as Button, Card, Field, Select, Dialog, Tabs, Tooltip and EmptyState (full list in the Which component table)."
---

# Divine UI (`@divineskins/ui`)

One package for the Divine look, so every Divine app matches the website without copying class strings. It holds the tokens (`tokens/tokens.json`, the single source of truth), the Tailwind setup that exposes them as `divine-*` classes (`tailwind.css` for Tailwind v4, `tailwind-preset` for v3), and React components copied from the site's live recipes. Source: `packages/ui` in the divine-skins monorepo; the version is in its `package.json`. `docs/DESIGN.md` at the repo root is a snapshot of these tokens, not a second source.

## Rules

1. **Component first.** If the package has it, import it. Don't rebuild a button, field, menu or dialog from copied classes.
2. **Tokens, not hex.** `bg-divine-surface`, `border-divine-border-subtle`, `text-divine-body-sm`, `rounded-xl`. Raw hex only when no token fits, and then add the token to the package.
3. **Theme colors for anything interactive.** Buttons, focus rings, checked and active states, links, selected rows and brand icons use `divine-accent`, `divine-accent-hover`, `divine-highlight` or `divine-icon-accent`. They follow the active theme (the site's Halloween theme turns them orange). `divine-primary` is the fixed brand purple for logo and brand art only.
4. **Dark only, three tiers.** Void `divine-bg`, then surface `divine-surface` / panel `divine-panel`, then border. No light mode, no nested cards.
5. **Every button is a pill.** Primary is the solid accent with the CTA bloom, secondary is white at 10%. Never the lilac gradient (`bg-divine-btn` is legacy).
6. **Gold is prestige.** `tone="gold"` and `divine-secondary` only for Divine+, earnings and featured moments.
7. **Restrained glow and motion.** Glow only on the primary CTA and active pill. Transitions 150 to 250ms, and every animation has a reduced-motion path (the package's components already do).
8. **Extend through `className`.** `cn()` merges with the caller's classes last, so they win. A one-off tweak goes in `className`; a tweak needed in several places becomes a variant in the package.

## Which component

| Need | Use |
|------|-----|
| Any clickable action | `Button` (`variant`: primary, secondary, ghost, ghost-danger, field, danger, danger-solid, success, link; `size`: sm, md, lg, icon-sm, icon) |
| A link styled as a button | `<Button asChild><a href="...">...</a></Button>` |
| Icon in a small raised square (section heads, feature and stat cards, dialog heads) | `IconTile` (`tone`: brand, gold, success, warning, danger, muted) |
| Status, count or label pill | `Badge` (`tone`, `size`, `caps`) |
| Filter or multi-pick pill that toggles (a filter row, "Cumulative", mobile filter tabs) | `Chip` (`selected`, `size`: sm, md); a link with the chip look is `chipVariants()` |
| A surface block | `Card` (`variant`: default, interactive, featured), with `CardHeader`, `CardTitle`, `CardDescription` |
| Text, multiline text | `Input`, `Textarea` |
| Label + hint + error around a control | `Field` (wires `id`, `aria-describedby`, `aria-invalid`) |
| Yes/no setting that applies at once | `Switch` |
| Tick a box (consent, multi-pick in a form) | `Checkbox` |
| Pick one of a fixed list | `Select` |
| Actions menu (account menu, row "...") | `DropdownMenu` |
| Free-form floating panel (filters, a picker with search) | `Popover`; a searchable or multi-pick picker is `PickerTrigger` + `Input size="sm"` + `PopoverItem` rows inside it |
| Blocking question or form on top of the page | `Dialog` |
| Switch between views of the same thing | `Tabs` (`variant`: pill for 2 to 4 segments, underline for page sections) |
| Explain an icon or a truncated label | `Tooltip` |
| Divider | `Separator` |
| Loading placeholder | `Skeleton` |
| Nothing to show yet | `EmptyState` (`size`: md for a section or tab, sm for a small panel; inside a `Card` when it needs a frame) |
| Two or three short choices that apply at once (Show / Hide, Yes / No) | `SegmentedControl` |
| Search box with a clear button | `SearchInput` |
| Inline notice in the page (not a toast) | `Alert` (`tone`: info, success, warning, danger) |
| Waiting, known or unknown amount | `Progress` (bar), `Spinner` (in place or in a button) |
| A person's picture with an initials fallback | `Avatar` |
| Paged list | `Pagination` (controlled, counted from 1) |
| FAQ, collapsible sections | `Accordion` (`type`: single, multiple) |
| Rows of data | `Table` |
| Divine+ subscriber mark | `DivinePlusBadge` |

Full API, props and examples: `references/components.md`. Every token with its value and use: `references/tokens.md`.

## Quick start

```tsx
import { Button, Card, CardTitle, Field, Input, IconTile } from "@divineskins/ui"
import { Download, Sparkles } from "lucide-react"

<Card>
  <div className="flex items-center gap-3">
    <IconTile tone="brand"><Sparkles /></IconTile>
    <CardTitle>New release</CardTitle>
  </div>
  <Field label="Mod name" hint="Shown on the mod page.">
    <Input placeholder="e.g. Demonic Kled" />
  </Field>
  <div className="mt-5 flex gap-3">
    <Button><Download /> Install</Button>
    <Button variant="secondary">Details</Button>
  </div>
</Card>
```

Icons are `lucide-react`, passed bare: the component sets their size.

## Setting it up in an app

- **apps/web** is already wired: it links the package source (no build), the Tailwind preset is in `tailwind.config.js`, its old `@/components/ui/icon-tile` path re-exports the package, and `@/components/ui/DivinePlusBadge` wraps the package's badge. Its other `@/components/ui/*` files are the web's own; several are stock shadcn (light-mode vars, `rounded-md`), so don't copy their styling into new Divine UI.
- **Another app in the monorepo:** copy the four pieces in `packages/ui/README.md` ("Use it in this repo"): the `file:` dependency, the Tailwind preset and content path, the Vite `@divineskins/source` condition and the resolver plugin that maps the package's imports to the app's React and Radix, and the tsconfig `customConditions` / `preserveSymlinks` / React paths.
- **An app in another repo** (Celestial, the wiki, a tool): it installs from GitHub Packages (private: the repo needs the `.npmrc` from the package README and a `read:packages` token). Then:
  - Tailwind v4: `@import "tailwindcss"; @import "@divineskins/ui/tailwind.css";` in the main CSS (it also scans the components' classes).
  - Tailwind v3: `presets: [require("@divineskins/ui/tailwind-preset")]` and `./node_modules/@divineskins/ui/dist/**/*.js` in `content`.
  - Load Manrope and Poppins, and put `bg-divine-bg font-manrope text-divine-text` on the body.
  - Next.js: the bundle is already marked `"use client"`, so Server Components can render package components directly.
  - This skill: `npx divine-ui link-skill` links it into `.claude/skills/`.
- **Themes:** import `@divineskins/ui/themes.css` and set `data-divine-theme="halloween"` (or `"original"`) on `<html>` or any element; everything under it re-skins. `divineThemes` lists the names. A one-off theme is the four variables `--divine-accent`, `--divine-accent-hover`, `--divine-highlight`, `--divine-icon-accent` on any element; unset, they fall back to the Divine purple. The website runs its own seasonal system and bridges to these variables in `apps/web/src/styles/SiteTheme.css`.

## Changing the package

- **A token or theme:** edit `tokens/tokens.json` (themes live under `themes`), run `npm run tokens` in `packages/ui` (regenerates `tokens.css`, `themes.css`, `tailwind.css` and `src/tokens.generated.ts`; a test fails if you skip it), update `references/tokens.md`. A theme change also goes in the website's `SiteTheme.css` (a web test compares them). The web picks it up through the preset, so run its typecheck and look at the pages that use it.
- **A component:** one file in `src/components/`, exported with its Props type (and cva variants) from `src/index.ts`. Copy the recipe from a live surface of the site and say which in a comment. Use `forwardRef` with a `displayName`, `cn()` with the caller's `className` last, theme colors for interactive states, the preset's `animate-divine-*` keyframes (not tailwindcss-animate, which consumers may not have). Gate state-driven animations with `motion-safe:` (`motion-safe:data-[state=open]:animate-divine-pop-in`): `motion-reduce:animate-none` loses to a `data-[state]` class on specificity. Every bare import must be a peer dependency (`tests/imports.test.ts`); the web resolves them from its own `node_modules`. Use classes that mean the same in Tailwind v3 and v4: no bare `rounded`, `shadow`, `blur`, `ring` or their `-sm` forms (sizes moved between versions), and no Tailwind `from-`/`to-` gradient stops without a `bg-linear-*`/`bg-gradient-*` class (v4 leaves them empty); give a gradient its own `backgroundImage` in the preset instead, like `bg-divine-frame`. Add a test in `tests/components.test.tsx`, a section in the playground (`npm run dev`), and an entry in `references/components.md`.
- **Verify:** in `packages/ui`, `npm test`, `npm run typecheck`, `npm run build`, and look at the playground in both themes (`?theme=halloween`). If the web uses what you changed, run its typecheck too.
- **Release** (only other repos need it): bump `version` (removing or renaming a prop or variant is a major), then run the "Publish @divineskins/ui" workflow from `main`, or publish from a machine with a `write:packages` token (README, Releasing).

## Gotchas

- `SelectLabel` must sit inside a `SelectGroup` (Radix throws otherwise).
- `Switch` renders a `button role="switch"`; give it a `name` and it adds a hidden checkbox so native `<form>` posts include it.
- `TooltipProvider` is optional. Wrap the app in it so moving between neighbouring tooltips opens them at once; without it each `Tooltip` brings its own.
- `Field` takes exactly one control as its child and clones the wiring onto it; for a `Select`, the `SelectTrigger` picks the wiring up from context.
- tailwind-merge only knows the `divine-*` names registered in `src/lib/cn.ts`, which reads them from `tokens.json`. A token added under a new group (not spacing, radius, font size, shadow or gradient) may need registering there too.
